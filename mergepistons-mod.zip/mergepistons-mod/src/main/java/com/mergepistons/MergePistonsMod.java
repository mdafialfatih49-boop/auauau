package com.mergepistons;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.object.builder.v1.entity.FabricDefaultAttributeRegistry;
import net.fabricmc.fabric.api.event.player.PlayerBlockBreakEvents;
import net.fabricmc.fabric.api.item.v1.FabricItemSettings;
import net.fabricmc.fabric.api.itemgroup.v1.ItemGroupEvents;
import net.fabricmc.fabric.api.object.builder.v1.block.FabricBlockSettings;
import net.fabricmc.fabric.api.object.builder.v1.entity.FabricEntityTypeBuilder;
import net.minecraft.block.Block;
import net.minecraft.block.Blocks;
import net.minecraft.entity.EntityDimensions;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.SpawnGroup;
import net.minecraft.entity.passive.SheepEntity;
import net.minecraft.item.BlockItem;
import net.minecraft.item.Item;
import net.minecraft.item.ItemGroups;
import net.minecraft.item.SpawnEggItem;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.util.Identifier;

public class MergePistonsMod implements ModInitializer {
    public static final String MOD_ID = "mergepistons";

    public static Block SUPER_NETHERITE;
    public static Block UNBREAKABLE_BLOCK;
    public static EntityType<CoosheepEntity> COOSHEEP;
    public static Item COOSHEEP_SPAWN_EGG;

    public static Identifier id(String path) {
        return new Identifier(MOD_ID, path);
    }

    @Override
    public void onInitialize() {
        SUPER_NETHERITE = Registry.register(Registries.BLOCK, id("super_netherite"),
                new Block(FabricBlockSettings.copyOf(Blocks.NETHERITE_BLOCK).strength(80.0f, 2000.0f)));
        Registry.register(Registries.ITEM, id("super_netherite"),
                new BlockItem(SUPER_NETHERITE, new FabricItemSettings().fireproof()));

        UNBREAKABLE_BLOCK = Registry.register(Registries.BLOCK, id("unbreakable_block"),
                new Block(FabricBlockSettings.copyOf(Blocks.BEDROCK)));
        Registry.register(Registries.ITEM, id("unbreakable_block"),
                new BlockItem(UNBREAKABLE_BLOCK, new FabricItemSettings().fireproof()));

        COOSHEEP = Registry.register(Registries.ENTITY_TYPE, id("coosheep"),
                FabricEntityTypeBuilder.create(SpawnGroup.CREATURE, CoosheepEntity::new)
                        .dimensions(EntityDimensions.fixed(0.9f, 1.3f))
                        .trackRangeChunks(10)
                        .build());
        FabricDefaultAttributeRegistry.register(COOSHEEP, SheepEntity.createSheepAttributes());

        COOSHEEP_SPAWN_EGG = Registry.register(Registries.ITEM, id("coosheep_spawn_egg"),
                new SpawnEggItem(COOSHEEP, 0xE09650, 0x50280F, new FabricItemSettings()));

        ItemGroupEvents.modifyEntriesEvent(ItemGroups.BUILDING_BLOCKS).register(entries -> {
            entries.add(SUPER_NETHERITE);
            entries.add(UNBREAKABLE_BLOCK);
        });
        ItemGroupEvents.modifyEntriesEvent(ItemGroups.SPAWN_EGGS).register(entries -> entries.add(COOSHEEP_SPAWN_EGG));

        // Unbreakable Block tidak bisa dihancurkan sama sekali, termasuk di creative.
        PlayerBlockBreakEvents.BEFORE.register((world, player, pos, state, blockEntity) ->
                !state.isOf(UNBREAKABLE_BLOCK));
    }
}
