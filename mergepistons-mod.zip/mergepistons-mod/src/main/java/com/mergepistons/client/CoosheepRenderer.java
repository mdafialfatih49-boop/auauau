package com.mergepistons.client;

import com.mergepistons.CoosheepEntity;
import net.minecraft.client.render.entity.EntityRendererFactory;
import net.minecraft.client.render.entity.MobEntityRenderer;
import net.minecraft.client.render.entity.model.EntityModelLayers;
import net.minecraft.client.render.entity.model.SheepEntityModel;
import net.minecraft.util.Identifier;

public class CoosheepRenderer extends MobEntityRenderer<CoosheepEntity, SheepEntityModel<CoosheepEntity>> {
    private static final Identifier TEXTURE = new Identifier("textures/entity/sheep/sheep.png");

    public CoosheepRenderer(EntityRendererFactory.Context ctx) {
        super(ctx, new SheepEntityModel<>(ctx.getPart(EntityModelLayers.SHEEP)), 0.7f);
        this.addFeature(new CoosheepFurFeature(this, ctx.getModelLoader()));
    }

    @Override
    public Identifier getTexture(CoosheepEntity entity) {
        return TEXTURE;
    }
}
