package com.mergepistons.client;

import com.mergepistons.MergePistonsMod;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.rendering.v1.EntityRendererRegistry;

public class MergePistonsClient implements ClientModInitializer {
    @Override
    public void onInitializeClient() {
        EntityRendererRegistry.register(MergePistonsMod.COOSHEEP, CoosheepRenderer::new);
    }
}
