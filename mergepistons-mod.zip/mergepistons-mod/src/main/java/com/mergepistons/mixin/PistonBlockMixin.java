package com.mergepistons.mixin;

import com.mergepistons.MergeManager;
import net.minecraft.block.BlockState;
import net.minecraft.block.PistonBlock;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(PistonBlock.class)
public class PistonBlockMixin {
    @Inject(method = "tryMove", at = @At("HEAD"), cancellable = true)
    private void mergepistons$tryMerge(World world, BlockPos pos, BlockState state, CallbackInfo ci) {
        // Tanpa ruang kosong di tengah (P B B P): piston ini tidak perlu memanjang lagi.
        if (MergeManager.tryMerge(world, pos, state) == 2) {
            ci.cancel();
        }
    }
}
